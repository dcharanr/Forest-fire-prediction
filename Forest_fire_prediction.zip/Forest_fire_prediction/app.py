import pickle
from flask import Flask, request, render_template
import numpy as np
import pandas as pd
from logging import getLogger, basicConfig, INFO, error
import matplotlib
matplotlib.use('Agg')  # Use a non-interactive backend
import matplotlib.pyplot as plt
import io
import base64

log = getLogger(__name__)
basicConfig(level=INFO)

with open('model.pkl', 'rb') as file:
    model_C = pickle.load(file)

app = Flask(__name__)

# Route for homepage
@app.route('/')
def home():
    log.info('Home page loaded successfully')
    return render_template('index.html')

# Route for Classification Model
@app.route('/predictC', methods=['POST', 'GET'])
def predictC():
    if request.method == 'POST':
        try:
            # reading the inputs given by the user
            Temperature = float(request.form['Temperature'])
            Wind_Speed = int(request.form['Ws'])
            FFMC = float(request.form['FFMC'])
            features = [Temperature, Wind_Speed, FFMC]
            Float_features = [float(x) for x in features]
            final_features = [np.array(Float_features)]

            probabilities = model_C.predict_proba(final_features)[0]
            prediction = model_C.predict(final_features)[0]
            fire_probability = probabilities[1]
            safe_probability = 1 - fire_probability

            log.info('Prediction done for Classification model')
            if prediction == 0:
                text = 'Forest is Safe!'
            else:
                text = 'Forest is in Danger!'

            output_text = "{} --- Chance of Fire is {:.2f}%".format(text, fire_probability * 100)
            labels = [f'Fire Risk ({fire_probability * 100:.2f}%)', f'Safe Zone ({safe_probability * 100:.2f}%)']
            sizes = [fire_probability, safe_probability]
            colors = ['orangered', 'forestgreen']

            fig1, ax = plt.subplots(figsize=(6, 4))
            ax.pie(sizes, labels=labels, colors=colors, autopct='%1.1f%%', startangle=90)
            ax.axis('equal')  # Equal aspect ratio ensures that pie is drawn as a circle.
            ax.set_title('Forest Fire Risk')

            png_image = io.BytesIO()
            fig1.savefig(png_image, format='png')
            png_image.seek(0)

            # Encode PNG image to base64 string
            png_image_d = base64.b64encode(png_image.getvalue()).decode('utf-8')

            # Generate a bar chart based on the input features
            x = ['Temperature', 'Wind Speed', 'FFMC']
            y = [Temperature, Wind_Speed, FFMC]
            fig, ax = plt.subplots(figsize=(6, 4))
            ax.bar(x, y)
            ax.set_title('Input Features')
            ax.set_xlabel('Feature')
            ax.set_ylabel('Value')

            # Convert plot to PNG image
            png_image = io.BytesIO()
            fig.savefig(png_image, format='png')
            png_image.seek(0)

            # Encode PNG image to base64 string
            png_image_data = base64.b64encode(png_image.getvalue()).decode('utf-8')


            return render_template('index.html', prediction_text1=output_text, plot_url=png_image_data, plot_url1=png_image_d)

        except Exception as e:
            log.error('Input error, check input', e)
            return render_template('index.html', prediction_text1="Check the Input again!!!")

if __name__ == "__main__":
    app.run(debug=True, port=5000)